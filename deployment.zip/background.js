/**
 * @param request
 * @return {string|undefined}
 */
const constructUrl = request => {
    const chronoBaseUrl = 'https://api.chrono.gg/';
    const steamBaseUrl = `https://store.steampowered.com/`;
    switch (request.type) {
        case 'daily':
            return `${chronoBaseUrl}sale`;
        case 'coinshop':
            return `${chronoBaseUrl}shop`;
        case 'steamPrice':
            return `${steamBaseUrl}api/appdetails?appids=${request.id}`;
        case 'steamReview':
            return `${steamBaseUrl}appreviews/${request.id}?json=1`;
    }
};

/**
 * @type {{get: (function(string): Promise<*>)}}
 */
const Ajax = {
    get: url => new Promise((resolve, reject) => {
        if (!url) return reject('No url given');
        const request = new XMLHttpRequest();
        request.open('GET', url, true);
        request.onreadystatechange = function () {
            if (request.readyState !== XMLHttpRequest.DONE)
                return;
            return request.status >= 200 && request.status < 300
                ? resolve(request.responseText)
                : reject(request.responseText);
        };
        request.send();
    })
};

chrome.runtime.onMessage.addListener(function (request, sender, respond) {
    switch (request.method) {
        case 'httpGet':
            const url = constructUrl(request);
            const start = Date.now();
            Ajax.get(url)
                .then(JSON.parse)
                .then(resp => respond({
                    success: true,
                    data: resp,
                    meta: {
                        url: url,
                        method: 'GET',
                        time: ((Date.now() - start) / 1000).toFixed(3)
                    }
                }))
                .catch(error => respond({
                    success: false,
                    data: error,
                    meta: {
                        url: url,
                        method: 'GET',
                        time: ((Date.now() - start) / 1000).toFixed(3)
                    }
                }));
            break;
        default:
            respond({success: false, data: `Unknown method ${request.method}`});
            break;
    }
    return true;
});